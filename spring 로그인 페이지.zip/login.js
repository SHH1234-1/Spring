const input_id = document.querySelector('#id');
input_id.onblur = () => {
    if(input_id.value.length == 0){
        const id_error = document.querySelector('#id_error'); //아이디 입력 하지 않을때 에러메세지
        id_error.style.display = "block";
    }else {
        const id_error = document.querySelector('#id_error');
        id_error.style.display = "none";
    }
}

const submit_button = document.querySelector('.input_submit'); //로그인 버튼을 눌렀을때
submit_button.onclick = () => {
    if(input_id.value.length == 0){ //아이디가 입력되어 있지 않다면
        const id_error = document.querySelector('#id_error');  //에러메세지
        id_error.style.display = "block";
    }else {
        const id_error = document.querySelector('#id_error');
        id_error.style.display = "none";
        
        const input_pwd = document.querySelector('#pwd');  
        if(input_pwd.value.length == 0){ //비밀번호가 입력되어 있지 않다면
            const pwd_error = document.querySelector('#pwd_error');  
            pwd_error.style.display = "block"; //에러메세지
        }else {
            const pwd_error = document.querySelector('#pwd_error');
			const loginform = document.querySelector('#loginform'); 
			const submitflag = document.querySelector('#submitflag'); 
            pwd_error.style.display = "none"; //비밀번호 에러메세지가 뜨지 않는다면
			submitflag.value = "true";
			loginform.submit();
			
        }
    }
}

const login_ch_text = document.querySelector('.login_ch_text');
const id_check = document.querySelector('#id_check');
login_ch_text.onclick = () => {
    if(id_check.value == "on"){
        id_check.value = "off";
        id_check.checked = false;
    }else {
        id_check.value = "on";
        id_check.checked = true;
    }
}